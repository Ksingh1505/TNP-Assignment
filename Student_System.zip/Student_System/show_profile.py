import json
from login import logged_user, logged

def show_profile():
    if not logged:
        print("\n⚠️ Please login first.")
        return

    with open("database.json", "r") as file:
        data = json.load(file)

    student = data.get(logged_user, None)
    if student:
        print("\n--- Student Profile ---")
        for key, value in student.items():
            if key != "password":
                print(f"{key.capitalize()}: {value}")
    else:
        print("Profile not found.")
