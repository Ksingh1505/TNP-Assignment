from register import register
from login import login
from show_profile import show_profile
from update_profile import update_profile
from logout import logout

def terminate():
    print("\n🚪 Exiting the system. Goodbye!")
    exit()

def main():
    print("\n=============================")
    print("   Welcome to LNCT System   ")
    print("=============================")

    response = input('''
Choose option:
1. Registration
2. Login
3. Show Profile
4. Update Profile
5. Logout
6. Main Menu
7. Exit

Select option (1-7): ''')

    if response == '1':
        register()
    elif response == '2':
        login()
    elif response == '3':
        show_profile()
    elif response == '4':
        update_profile()
    elif response == '5':
        logout()
    elif response == '6':
        main()
    elif response == '7':
        terminate()
    else:
        print("Invalid Choice, Please select correct option.")

    input("\nPress Enter to continue...")
    main()

if __name__ == "__main__":
    main()
