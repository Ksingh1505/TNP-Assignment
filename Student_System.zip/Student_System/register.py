import json

def register():
    print("\n--- Student Registration ---")

    # Load existing data
    try:
        with open("database.json", "r") as file:
            data = json.load(file)
    except:
        data = {}

    username = input("Enter Username: ")
    if username in data:
        print("Username already exists! Try again.")
        return

    # Taking 10+ fields
    student = {
        "name": input("Full Name: "),
        "age": input("Age: "),
        "gender": input("Gender: "),
        "email": input("Email: "),
        "phone": input("Phone Number: "),
        "course": input("Course: "),
        "year": input("Year: "),
        "address": input("Address: "),
        "roll_no": input("Roll Number: "),
        "password": input("Create Password: ")
    }

    # Save data
    data[username] = student
    with open("database.json", "w") as file:
        json.dump(data, file, indent=4)

    print("\n✅ Registration successful! You can now login.")
