import json
from login import logged_user, logged

def update_profile():
    if not logged:
        print("\n⚠️ Please login first.")
        return

    with open("database.json", "r") as file:
        data = json.load(file)

    student = data.get(logged_user, None)
    if not student:
        print("Profile not found.")
        return

    print("\n--- Update Profile ---")
    for key, value in student.items():
        if key != "password":
            new_value = input(f"{key.capitalize()} ({value}) - new value or press Enter to skip: ")
            if new_value.strip() != "":
                student[key] = new_value

    data[logged_user] = student
    with open("database.json", "w") as file:
        json.dump(data, file, indent=4)

    print("\n✅ Profile updated successfully!")
