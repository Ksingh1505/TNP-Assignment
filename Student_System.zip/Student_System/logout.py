from login import logged_user, logged

def logout():
    global logged_user, logged
    if logged:
        print(f"\n👋 {logged_user} logged out successfully.")
        logged_user = None
        logged = False
    else:
        print("\n⚠️ No user is logged in.")
