import json

logged_user = None
logged = False

def login():
    global logged_user, logged

    print("\n--- Student Login ---")

    try:
        with open("database.json", "r") as file:
            data = json.load(file)
    except:
        print("No users registered yet.")
        return

    username = input("Username: ")
    password = input("Password: ")

    if username in data and data[username]["password"] == password:
        logged_user = username
        logged = True
        print(f"\n✅ Login successful! Welcome {data[username]['name']}.")
    else:
        print("❌ Invalid username or password.")
