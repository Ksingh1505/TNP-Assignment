import register
import login
import quiz
import profile
import results

def main():
    current_user = None
    while True:
        print("\n--- STUDENT QUIZ APP ---")
        print("1. Register")
        print("2. Login")
        print("3. Update Profile")
        print("4. View Profile")
        print("5. Attempt Quiz")
        print("6. View My Results")
        print("7. Logout")
        print("8. Exit")

        choice = input("Enter your choice: ").strip()

        if choice == '1':
            register.register_user()

        elif choice == '2':
            current_user = login.login_user()

        elif choice == '3':
            if current_user:
                profile.update_profile(current_user)
            else:
                print("Please login first.")

        elif choice == '4':
            if current_user:
                profile.show_profile(current_user)
            else:
                print("Please login first.")

        elif choice == '5':
            if current_user:
                quiz.attempt_quiz(current_user)
            else:
                print("Please login first.")

        elif choice == '6':
            if current_user:
                results.show_my_results(current_user)
            else:
                print("Please login first.")

        elif choice == '7':
            if current_user:
                print(f"User {current_user['email']} logged out.")
                current_user = None
            else:
                print("No user is currently logged in.")

        elif choice == '8':
            print("Exiting program...")
            break
        else:
            print("Invalid choice. Try again.")

if __name__ == "__main__":
    main()
