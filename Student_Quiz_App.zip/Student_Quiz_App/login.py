def login_user():
    print("\n--- Login ---")
    email = input("Enter email: ").strip()
    password = input("Enter password: ").strip()

    if email == "admin@123" and password == "admin1234":
        print("Admin login successful.")
        admin_panel()
        return None

    with open("users.txt", "r") as f:
        for line in f:
            data = line.strip().split(",")
            if len(data) >= 2 and data[0] == email and data[1] == password:
                print(f"Login successful. Welcome {data[2]}!")
                return {"email": data[0], "name": data[2], "branch": data[3], "year": data[4], "contact": data[5]}
    print("Invalid credentials.")
    return None


def admin_panel():
    while True:
        print("\n--- ADMIN PANEL ---")
        print("1. View All Users")
        print("2. View All Results")
        print("3. Logout")
        choice = input("Enter choice: ")

        if choice == "1":
            try:
                with open("users.txt", "r") as f:
                    users = f.readlines()
                    if not users:
                        print("No registered users.")
                    for u in users:
                        print(u.strip())
            except FileNotFoundError:
                print("No user data found.")

        elif choice == "2":
            try:
                with open("results.txt", "r") as f:
                    results = f.readlines()
                    if not results:
                        print("No results found.")
                    for r in results:
                        print(r.strip())
            except FileNotFoundError:
                print("No results file found.")

        elif choice == "3":
            print("Logging out from admin panel...")
            break
        else:
            print("Invalid choice.")
