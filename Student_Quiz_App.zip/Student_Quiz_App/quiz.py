import random
import datetime

def attempt_quiz(user):
    print("\n--- Quiz Categories ---")
    print("1. DSA\n2. DBMS\n3. PYTHON")
    choice = input("Choose a category: ").strip()

    if choice == '1':
        filename = "questions/dsa.txt"
        category = "DSA"
    elif choice == '2':
        filename = "questions/dbms.txt"
        category = "DBMS"
    elif choice == '3':
        filename = "questions/python.txt"
        category = "PYTHON"
    else:
        print("Invalid choice.")
        return

    try:
        with open(filename, "r") as f:
            data = f.read().strip().split("\n\n")
    except FileNotFoundError:
        print("Question file not found.")
        return

    questions = []
    for block in data:
        lines = block.strip().split("\n")
        if len(lines) >= 6:
            q = lines[0]
            options = lines[1:5]
            ans = lines[5].strip()
            questions.append((q, options, ans))

    random.shuffle(questions)
    selected = questions[:5]

    score = 0
    for i, (q, opts, ans) in enumerate(selected, 1):
        print(f"\nQ{i}. {q}")
        random.shuffle(opts)
        for j, opt in enumerate(opts, 1):
            print(f"{j}. {opt}")
        choice = input("Enter option number: ").strip()
        if choice.isdigit() and opts[int(choice)-1] == ans:
            score += 1

    total = len(selected)
    print(f"\nYour Score: {score}/{total}")

    with open("results.txt", "a") as f:
        f.write(f"{user['email']},{category},{score}/{total},{datetime.datetime.now()}\n")
