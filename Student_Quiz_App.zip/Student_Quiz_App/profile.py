def update_profile(user):
    print("\n--- Update Profile ---")
    name = input(f"Enter name [{user['name']}]: ") or user['name']
    branch = input(f"Enter branch [{user['branch']}]: ") or user['branch']
    year = input(f"Enter year [{user['year']}]: ") or user['year']
    contact = input(f"Enter contact [{user['contact']}]: ") or user['contact']

    updated_lines = []
    with open("users.txt", "r") as f:
        for line in f:
            data = line.strip().split(",")
            if data[0] == user['email']:
                updated_lines.append(f"{data[0]},{data[1]},{name},{branch},{year},{contact}\n")
            else:
                updated_lines.append(line)

    with open("users.txt", "w") as f:
        f.writelines(updated_lines)

    print("Profile updated successfully.")


def show_profile(user):
    print("\n--- User Profile ---")
    for k, v in user.items():
        print(f"{k.capitalize()}: {v}")
