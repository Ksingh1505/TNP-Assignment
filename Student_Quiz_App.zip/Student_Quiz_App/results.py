def show_my_results(user):
    print("\n--- My Quiz Results ---")
    try:
        with open("results.txt", "r") as f:
            found = False
            for line in f:
                data = line.strip().split(",")
                if data[0] == user['email']:
                    print(f"Category: {data[1]} | Score: {data[2]} | Date: {data[3]}")
                    found = True
            if not found:
                print("No results found for your account.")
    except FileNotFoundError:
        print("No results recorded yet.")
