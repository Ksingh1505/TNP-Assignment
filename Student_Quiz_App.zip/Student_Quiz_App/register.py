def register_user():
    print("\n--- User Registration ---")
    name = input("Enter full name: ").strip()
    email = input("Enter email: ").strip()
    password = input("Enter password: ").strip()
    branch = input("Enter branch: ").strip()
    year = input("Enter year: ").strip()
    contact = input("Enter contact number: ").strip()

    with open("users.txt", "a") as f:
        f.write(f"{email},{password},{name},{branch},{year},{contact}\n")

    print("Registration successful.")
